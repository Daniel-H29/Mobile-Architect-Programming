package com.example.inventoryapp

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.inventoryapp.data.AppDatabaseHelper
import com.example.inventoryapp.databinding.ActivityAddEditItemBinding

class AddEditItemActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddEditItemBinding
    private lateinit var dbHelper: AppDatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityAddEditItemBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = AppDatabaseHelper(this)

        binding.btnSaveItem.setOnClickListener {

            val name = binding.etItemName.text.toString()
            val quantityText = binding.etQuantity.text.toString()

            if (name.isBlank() || quantityText.isBlank()) {
                Toast.makeText(this, "Enter item name and quantity", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val quantity = quantityText.toInt()

            dbHelper.insertItem(name, quantity)

            Toast.makeText(this, "Item saved", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
@echo off
echo This project is intended to be opened in Android Studio.

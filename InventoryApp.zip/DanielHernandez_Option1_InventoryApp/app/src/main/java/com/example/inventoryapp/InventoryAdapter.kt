package com.example.inventoryapp

import android.database.Cursor
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.inventoryapp.databinding.ItemInventoryCardBinding

class InventoryAdapter(
    private var cursor: Cursor,
    private val onDelete: (Long) -> Unit,
    private val onUpdate: (Long, Int) -> Unit
) : RecyclerView.Adapter<InventoryAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemInventoryCardBinding)
        : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemInventoryCardBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        cursor.moveToPosition(position)

        val id = cursor.getLong(cursor.getColumnIndexOrThrow("id"))
        val name = cursor.getString(cursor.getColumnIndexOrThrow("name"))
        var qty = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"))

        holder.binding.tvItemName.text = name
        holder.binding.tvQuantity.text = qty.toString()

        holder.binding.btnDelete.setOnClickListener {
            onDelete(id)
        }

        holder.binding.btnPlus.setOnClickListener {
            qty++
            onUpdate(id, qty)
        }

        holder.binding.btnMinus.setOnClickListener {
            if (qty > 0) {
                qty--
                onUpdate(id, qty)
            }
        }
    }

    override fun getItemCount(): Int = cursor.count

    fun swapCursor(newCursor: Cursor) {
        cursor.close()
        cursor = newCursor
        notifyDataSetChanged()
    }
}
package com.example.inventoryapp.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class AppDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        // Users table for login
        db.execSQL(
            """
            CREATE TABLE $TABLE_USERS (
                $COL_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_USERNAME TEXT NOT NULL UNIQUE,
                $COL_PASSWORD TEXT NOT NULL
            );
            """.trimIndent()
        )

        // Inventory table for app data
        db.execSQL(
            """
            CREATE TABLE $TABLE_INVENTORY (
                $COL_ITEM_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_ITEM_NAME TEXT NOT NULL,
                $COL_ITEM_QTY INTEGER NOT NULL
            );
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_INVENTORY")
        onCreate(db)
    }

    // ---------------------------
    // USER METHODS
    // ---------------------------
    fun createUser(username: String, password: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_USERNAME, username.trim())
            put(COL_PASSWORD, password)
        }
        return try {
            db.insertOrThrow(TABLE_USERS, null, values) != -1L
        } catch (e: Exception) {
            false // username taken, etc.
        }
    }

    fun validateUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_USERS,
            arrayOf(COL_USER_ID),
            "$COL_USERNAME=? AND $COL_PASSWORD=?",
            arrayOf(username.trim(), password),
            null, null, null
        )
        val ok = cursor.count > 0
        cursor.close()
        return ok
    }

    // ---------------------------
    // INVENTORY METHODS (CRUD)
    // ---------------------------
    fun insertItem(name: String, qty: Int): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_ITEM_NAME, name.trim())
            put(COL_ITEM_QTY, qty)
        }
        return db.insert(TABLE_INVENTORY, null, values)
    }

    fun updateItem(id: Long, name: String, qty: Int): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_ITEM_NAME, name.trim())
            put(COL_ITEM_QTY, qty)
        }
        return db.update(TABLE_INVENTORY, values, "$COL_ITEM_ID=?", arrayOf(id.toString()))
    }

    fun deleteItem(id: Long): Int {
        val db = writableDatabase
        return db.delete(TABLE_INVENTORY, "$COL_ITEM_ID=?", arrayOf(id.toString()))
    }

    fun getAllItems(): Cursor {
        val db = readableDatabase
        return db.query(
            TABLE_INVENTORY,
            arrayOf(COL_ITEM_ID, COL_ITEM_NAME, COL_ITEM_QTY),
            null, null, null, null,
            "$COL_ITEM_NAME COLLATE NOCASE ASC"
        )
    }

    companion object {
        private const val DATABASE_NAME = "inventory_app.db"
        private const val DATABASE_VERSION = 1

        const val TABLE_USERS = "users"
        const val COL_USER_ID = "id"
        const val COL_USERNAME = "username"
        const val COL_PASSWORD = "password"

        const val TABLE_INVENTORY = "inventory"
        const val COL_ITEM_ID = "id"
        const val COL_ITEM_NAME = "name"
        const val COL_ITEM_QTY = "quantity"
    }
}
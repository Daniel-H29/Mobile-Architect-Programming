package com.example.inventoryapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.inventoryapp.databinding.ActivitySmsSettingsBinding

class SmsSettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySmsSettingsBinding

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            binding.tvPermissionStatus.text = if (granted) "Granted" else "Denied"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySmsSettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRequestPermission.setOnClickListener {
            requestPermissionLauncher.launch(Manifest.permission.SEND_SMS)
        }

        binding.btnCheckPermission.setOnClickListener {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
            ) == PackageManager.PERMISSION_GRANTED

            binding.tvPermissionStatus.text = if (granted) "Granted" else "Denied"
        }

        binding.btnSendTestSms.setOnClickListener {
            Toast.makeText(this, "SMS feature coming next step", Toast.LENGTH_SHORT).show()
        }
    }
}
package com.example.inventoryapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.example.inventoryapp.data.AppDatabaseHelper
import com.example.inventoryapp.databinding.ActivityInventoryBinding

class InventoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityInventoryBinding
    private lateinit var dbHelper: AppDatabaseHelper
    private lateinit var adapter: InventoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityInventoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = AppDatabaseHelper(this)

        setupRecycler()

        binding.fabAddItem.setOnClickListener {
            startActivity(Intent(this, AddEditItemActivity::class.java))
        }

        binding.btnSmsSettings.setOnClickListener {
            startActivity(Intent(this, SmsSettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        loadItems()
    }

    private fun setupRecycler() {

        adapter = InventoryAdapter(
            dbHelper.getAllItems(),
            onDelete = { id ->
                dbHelper.writableDatabase.delete(
                    "inventory",
                    "id=?",
                    arrayOf(id.toString())
                )
                loadItems()
            },
            onUpdate = { id, newQty ->
                dbHelper.writableDatabase.execSQL(
                    "UPDATE inventory SET quantity=? WHERE id=?",
                    arrayOf(newQty, id)
                )
                loadItems()
            }
        )

        binding.rvInventoryGrid.layoutManager = GridLayoutManager(this, 2)
        binding.rvInventoryGrid.adapter = adapter
    }

    private fun loadItems() {
        val cursor = dbHelper.getAllItems()
        adapter.swapCursor(cursor)
    }
}